﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.IO;

namespace Find_the_Spot
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;

        //Variables // Variables //Variables //Variables //Variables //Variables //Variables \\
        //Texturer
        Texture2D menu;
        Texture2D map;
        Texture2D cursor;
        Texture2D transpBlack;
        Texture2D gameLogo;

        //Bilar
        Texture2D lvl1Car;
        Texture2D lvl2Car;
        Texture2D lvl3Car;

        //Buttons
        Texture2D playButtonTex;
        Texture2D settingsButtonTex;
        Texture2D quitButtonTex;
        //Texture2D quitToMainMenuButtonTex;

        //Buttons-Positions
        Vector2 playButtonPos;
        Vector2 settingsButtonPos;
        Vector2 quitButtonPos;
        //Vector2 quitToMainMenuButtonPos;

        //Collisions
        Rectangle mainFrame;
        Rectangle pausedFrame;

        //Vector2's
        Vector2 mousePosition;
        Vector2 lvl1CarPos;
        Vector2 lvl2CarPos;
        Vector2 lvl3CarPos;

        Vector2 player1Spawn;
        Vector2 player2Spawn;

        //Spritefonts
        SpriteFont scoreFont;
        SpriteFont timerFont;

        //Int's
        int fullScreenWidth = 1920;
        int fullScreenHeight = 1080;
        int player1Score = 0;
        int player2Score = 0;

        //Int timers
        int counter = 1;
        int limit = 60;
        float countDuration = 1f; //Var andra sekund
        float currentTime = 0f;

        //Float's
        float lvl1Speed = 5f;
        float lvl2Speed = 6f;
        float lvl3Speed = 7f;

        //Float's | Upgrades

        //Strings
        string _gameState = "mainMenu";
        string currentCar = "lvl1Car";


        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";

            graphics.PreferredBackBufferHeight = fullScreenHeight;
            graphics.PreferredBackBufferWidth = fullScreenWidth;
            graphics.IsFullScreen = true;

            IsMouseVisible = false;
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
            playButtonPos = new Vector2(60 ,855);
            quitButtonPos = new Vector2(1425, 845);
            settingsButtonPos = new Vector2(610, 850);

            player1Spawn = new Vector2(200, 1000);

            lvl1CarPos = player1Spawn;
            lvl2CarPos = player1Spawn;
            lvl3CarPos = player1Spawn;
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            menu = Content.Load<Texture2D>("backgroundImage");
            gameLogo = Content.Load<Texture2D>("gameLogo");
            transpBlack = Content.Load<Texture2D>("transpBlack");
            map = Content.Load<Texture2D>("map");
            playButtonTex = Content.Load<Texture2D>("playButton");
            settingsButtonTex = Content.Load<Texture2D>("settingsButton");
            quitButtonTex = Content.Load<Texture2D>("quitButton");


            //Ladda in font
            scoreFont = Content.Load<SpriteFont>("font");
            timerFont = Content.Load<SpriteFont>("timerFont");

            //Laddar in bilarna
            lvl1Car = Content.Load<Texture2D>("lvl1Car");
            lvl2Car = Content.Load<Texture2D>("lvl2Car");
            lvl3Car = Content.Load<Texture2D>("lvl3Car");

            mainFrame = new Rectangle(0, 0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);
            pausedFrame = new Rectangle(0, 0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);

            //Laddar in en custom muspekare
            cursor = Content.Load<Texture2D>("mouseCursor");
            // TODO: use this.Content to load your game content here
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape) && _gameState != "mainMenu")
                _gameState = "paused";

            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape) && _gameState == "paused")
                _gameState = "paused";

            // TODO: Add your update logic here


            base.Update(gameTime);
            //MouseState - Var musen befinner sig
            var mouseState = Mouse.GetState();
            mousePosition = new Vector2(mouseState.X, mouseState.Y);

            //Timer när spelet är igång (playing)
            if (_gameState == "playing")
            {
                currentTime += (float)gameTime.ElapsedGameTime.TotalSeconds; //Time passed since last Update() 

                if (currentTime >= countDuration)
                {
                    counter++;
                    currentTime -= countDuration; // "use up" the time
                                                  //any actions to perform
                }
                if (counter >= limit)
                {
                    counter = 0;//Reset the counter;
                                //any actions to perform
                }
            }
            

            #region mainMenu fix
            //Quitknapp funktion
            var quitButtonCol = new Rectangle(int.Parse(quitButtonPos.X.ToString()), int.Parse(quitButtonPos.Y.ToString()), quitButtonTex.Width, quitButtonTex.Height);
            if (quitButtonCol.Contains(mousePosition))
                if (Mouse.GetState().LeftButton == ButtonState.Pressed)
                    Exit();

            //Settingsknapp funktion
            var settingsButtonCol = new Rectangle(int.Parse(settingsButtonPos.X.ToString()), int.Parse(settingsButtonPos.Y.ToString()), settingsButtonTex.Width, settingsButtonTex.Height);
            if (settingsButtonCol.Contains(mousePosition))
                if (Mouse.GetState().LeftButton == ButtonState.Pressed)
                    _gameState = "settingsFromMenu";

            //Playknapp funktion
            var playButtonCol = new Rectangle(int.Parse(playButtonPos.X.ToString()), int.Parse(playButtonPos.Y.ToString()), playButtonTex.Width, playButtonTex.Height);
            if (playButtonCol.Contains(mousePosition))
                if (Mouse.GetState().LeftButton == ButtonState.Pressed)
                    _gameState = "playing";
            #endregion
            #region pauseMenu Fix

            if (_gameState == "paused")
            {
                quitButtonPos.X = 0;
                settingsButtonPos.X = 0;
                playButtonPos.X = 0;
                //quitToMainMenuButtonPos.X = 0;
                quitButtonPos.Y = 700;
                //quitToMainMenuButtonPos.Y = 700;
                settingsButtonPos.Y = 500;
                playButtonPos.Y = 300;

            //Quitknapp funktion
            var quitButtonCol2 = new Rectangle(int.Parse(quitButtonPos.X.ToString()), int.Parse(quitButtonPos.Y.ToString()), quitButtonTex.Width, quitButtonTex.Height);
            if (quitButtonCol2.Contains(mousePosition))
                if (Mouse.GetState().LeftButton == ButtonState.Pressed)
                    Exit();

            //Settingsknapp funktion
            var settingsButtonCol2 = new Rectangle(int.Parse(settingsButtonPos.X.ToString()), int.Parse(settingsButtonPos.Y.ToString()), settingsButtonTex.Width, settingsButtonTex.Height);
            if (settingsButtonCol.Contains(mousePosition))
                if (Mouse.GetState().LeftButton == ButtonState.Pressed)
                    _gameState = "settingsFromMenu";

            //Playknapp funktion
            var playButtonCol2 = new Rectangle(int.Parse(playButtonPos.X.ToString()), int.Parse(playButtonPos.Y.ToString()), playButtonTex.Width, playButtonTex.Height);
            if (playButtonCol.Contains(mousePosition))
                if (Mouse.GetState().LeftButton == ButtonState.Pressed)
                    _gameState = "playing";
            }
            #endregion
            #region Movement
            if (_gameState == "playing")
            {
                if (currentCar == "lvl1Car")
                    if (Keyboard.GetState().IsKeyDown(Keys.W))
                    {
                        lvl1CarPos.Y = lvl1CarPos.Y - lvl1Speed;
                    }
                if (Keyboard.GetState().IsKeyDown(Keys.S))
                {
                    lvl1CarPos.Y = lvl1CarPos.Y + lvl1Speed;
                }
                if (Keyboard.GetState().IsKeyDown(Keys.A))
                {
                    lvl1CarPos.X = lvl1CarPos.X - lvl1Speed;
                }
                if (Keyboard.GetState().IsKeyDown(Keys.D))
                {
                    lvl1CarPos.X = lvl1CarPos.X + lvl1Speed;
                }

                if (currentCar == "lvl2Car")
                    if (Keyboard.GetState().IsKeyDown(Keys.W))
                    {
                        lvl2CarPos.Y = lvl2CarPos.Y - lvl2Speed;
                    }
                if (Keyboard.GetState().IsKeyDown(Keys.S))
                {
                    lvl2CarPos.Y = lvl2CarPos.Y + lvl2Speed;
                }
                if (Keyboard.GetState().IsKeyDown(Keys.A))
                {
                    lvl2CarPos.X = lvl2CarPos.X - lvl2Speed;
                }
                if (Keyboard.GetState().IsKeyDown(Keys.D))
                {
                    lvl2CarPos.X = lvl2CarPos.X + lvl2Speed;
                }

                if (currentCar == "lvl3Car")
                    if (Keyboard.GetState().IsKeyDown(Keys.W))
                    {
                        lvl3CarPos.Y = lvl3CarPos.Y - lvl3Speed;
                    }
                if (Keyboard.GetState().IsKeyDown(Keys.S))
                {
                    lvl3CarPos.Y = lvl3CarPos.Y + lvl3Speed;
                }
                if (Keyboard.GetState().IsKeyDown(Keys.A))
                {
                    lvl3CarPos.X = lvl3CarPos.X - lvl3Speed;
                }
                if (Keyboard.GetState().IsKeyDown(Keys.D))
                {
                    lvl3CarPos.X = lvl3CarPos.X + lvl3Speed;
                }
            }
            
            #endregion
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.White);

            // Start building the sprite.
            spriteBatch.Begin();

            // Draw the background.
            spriteBatch.Draw(menu, mainFrame, Color.White);

            //Rita ut play knappen om _gameState är mainMenu
            
            if (_gameState != "mainMenu")
                spriteBatch.Draw(map, mainFrame, Color.White);

            if (currentCar == "lvl1Car" && _gameState == "playing")
                spriteBatch.Draw(lvl1Car, lvl1CarPos, Color.White);

            if (currentCar == "lvl2Car" && _gameState == "playing")
                spriteBatch.Draw(lvl2Car, lvl2CarPos, Color.White);

            if (currentCar == "lvl3Car" && _gameState == "playing")
                spriteBatch.Draw(lvl3Car, lvl3CarPos, Color.White);

            if (_gameState == "paused")
                spriteBatch.Draw(transpBlack, pausedFrame, Color.White);

            //Ritar ut poängtext
            if (_gameState == "playing")
            {
                spriteBatch.DrawString(scoreFont, "Player 2 Score: " + player2Score.ToString(), lvl1CarPos, Color.Black);
                spriteBatch.DrawString(scoreFont, "Player 1 Score: " + player1Score.ToString(), lvl2CarPos, Color.Black);
                spriteBatch.DrawString(timerFont, counter.ToString(), new Vector2(fullScreenWidth / 2, 50), Color.White);
            }

            if (_gameState == "mainMenu" || _gameState == "paused")
            {
                spriteBatch.Draw(playButtonTex, playButtonPos, Color.White);
                spriteBatch.Draw(quitButtonTex, quitButtonPos, Color.White);
                spriteBatch.Draw(settingsButtonTex, settingsButtonPos, Color.White);
                //spriteBatch.Draw(quitToMainMenuButtonTex, quitToMainMenuButtonPos, Color.White);
            }
            if (_gameState == "paused")
                spriteBatch.Draw(gameLogo, new Vector2(1200, 200), Color.White);

            //Ritar ut muspekaren
            if (_gameState != "playing")
                spriteBatch.Draw(cursor, mousePosition, Color.White);

            // End building the sprite.
            spriteBatch.End();


            // TODO: Add your drawing code here

            base.Draw(gameTime);
        }


        static void mainMenu()
        {

        }
    }
}
